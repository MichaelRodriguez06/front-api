import {Component} from '@angular/core';

/**
 * @title Toolbar overview
 */
@Component({
  selector: 'toolbar-overview-example',
  templateUrl: 'toolbar.component.html',
  styleUrls: ['toolbar.component.css'],

})
export class ToolbarOverviewExample {



}

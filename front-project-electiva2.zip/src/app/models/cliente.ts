export interface Cliente {
    id: string,
    sId: string,
    nombre: string,
    precio: number,
}
export abstract class AppRoutes {
    static readonly GET_LIST_CLIENTS = "AirFlight";
    static readonly POST_CLIENT = "productos";
    static readonly PUT_CLIENTE = "productos";
}

export const environment = {
  apiUrl: "https://localhost:7105",
  production: true
};

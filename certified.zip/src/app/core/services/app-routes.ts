export abstract class AppRoutes {
    static readonly GET_LIST_CLIENTS = "productos";
    static readonly POST_CLIENT = "productos";
    static readonly PUT_CLIENTE = "productos";
}

export const environment = {
  apiUrl: "https://10.4.74.145",
  production: true
};
